from engine.basepage import BasePage
class HomePage(BasePage):
    input_account = "id=>username"
    input_password = "id=>spa"
    search_submit_btn = "xpath=>//*[@id='btnLogin']"

    def type_account(self, text):
        self.type(self.input_account, text)

    def type_password(self,text):
        self.type(self.input_password, text)

    def send_submit_btn(self):
        self.click(self.search_submit_btn)
