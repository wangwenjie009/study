import time
import unittest
from engine.browser_engine import BrowserEngine
from pageobjects.baidu_homepages import HomePage
from pageobjects.baidu_news_home import NewsHomePage
from pageobjects.baidu_knows_home import KnowHomePage


class ViewNBANews(unittest.TestCase):
    def setUp(self):
        browse = BrowserEngine(self)
        self.driver = browse.open_browser(self)

    def tearDown(self):
        self.driver.quit()

    def test_view_nba_views(self):

        baiduhome = HomePage(self.driver)
        self.driver.find_element_by_xpath("//*[@id='u1']/a[@name='tj_trnews']").click()


        newshome = NewsHomePage(self.driver)
        self.driver.find_element_by_xpath('/html/body/div[1]/ul/li[4]/a').click()


        sportnewhome = KnowHomePage(self.driver)
        self.driver.find_element_by_xpath('//*[@id="ask-btn-new"]').click()
        sportnewhome.get_windows_img()


if __name__ == '__main__':
    unittest.main()
