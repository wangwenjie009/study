from engine.basepage import BasePage

class KnowHomePage(BasePage):

    #knows_link = "xpath=>//*[@id='channel-all']/div/ul/li[7]/a"
    knows_link = "xpath=>//*[@id='ask-btn-new']"

    def click_knows(self):
        self.click(self.knows_link)
        self.sleep(2)
