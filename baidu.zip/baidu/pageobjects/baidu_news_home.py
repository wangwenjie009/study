from engine.basepage import BasePage

class NewsHomePage(BasePage):

    # sports_link = "xpath=>//*[@id='channel-all']/div/ul/li[7]/a"

    news_link = "xpath=>//*[@id='header-link-wrapper']/li[4]/a"
    def click_news(self):
       self.click(self.news_link)
       self.sleep(2)

